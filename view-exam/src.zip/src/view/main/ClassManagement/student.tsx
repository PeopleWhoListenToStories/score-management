import React from 'react'

export default function student() {
    return (
        <div>
            学生管理
        </div>
    )
}
