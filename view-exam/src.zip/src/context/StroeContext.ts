import {createContext} from 'react';
import store from '../store/index'

export default createContext(store)