import { observable} from 'mobx';

export default class Test {
  @observable
  str:string = '测试'
}
 
 