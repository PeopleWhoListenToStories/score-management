import {useContext} from 'react';
import StoreContext from './StroeContext';

export default () => useContext(StoreContext);