/// <reference types="react-scripts" />
declare const window
declare const confirm
