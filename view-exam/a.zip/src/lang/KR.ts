const KR = {
    'menus.question':'문제',
    'menus.question.addQuestion': '질문 추가',
    'menus.question.questionType': '문제 유형',
    'menus.question.watchQuestions': '문 제 를 관찰 하 라',
    'menus.user':'사용자',
    'menus.user.AddTeacher':'투시도 선생님',
    'menus.user.ViewTeacher':'투시도 선생님',
    'menus.exam':'시험',
    'menus.exam.AddExamPage':"사용자 목록 페이지",
    'menus.exam.UserListPage':'페이지 편집',
    'menus.exam.EditPage':'클래스',
    'menus.class':'클래스',
    'menus.class.GeadePage':'사용자',
    'menus.class.RoomPage':'선생님 시험',
    'menus.class.StudentPage':'페이지',
    'menus.merge':'합병',
    'menus.merge.ExamPaperClassListPage':'페이지 편집',
    'menus.merge.ClassMate':'동창'
  }
  
  export default KR;